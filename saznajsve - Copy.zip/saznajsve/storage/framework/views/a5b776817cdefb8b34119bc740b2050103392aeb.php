<?php $__env->startSection('content'); ?>

<div class="row">
	
<?php if(Auth::user()->id == $post->user_id): ?>
 
	<div class="col-md-8 haha">
		<div id = "fuckimgs">
			<h1> <?php echo e($post->title); ?> </h1>
			<?php $br = 0;  ?>
			
			<?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
				<?php if($post->id == $image->post_id): ?>
				<a data-fancybox="group" class="lightbox" href="<?php echo e(asset('images/'. $image->name)); ?>">
				<img src="<?php echo e(asset('images/'. $image->name)); ?>" width="300" vspace="20" />
				</a>
				<?php $br = $br + 1; ?>
				<form name = "delete-image" action="/posts/<?php echo e($post->id); ?>/delete-image/<?php echo e($image->id); ?>" method="DELETE">
					<?php echo e(csrf_field()); ?>

					<input type="submit" value="Delete" class="btn btn-danger btn-sm">
				</form>
				<?php else: ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		

		<?php $globalbr = $br; ?>
		<p class="lead"> <?php echo e($post->body); ?> </p>
		<hr>
		<div class="tags">
			<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<button type="button" class="btn btn-info btn-sm">
				<?php echo e($tag->name); ?>

			</button>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<br>

		</div>
	</div>

	<div class="col-md-4">
		<div class="well well-sm">

			<dl class="dl-horizontal">
				<dt> Slug: </dt>
				<dd> <a href="<?php echo e(url('blog/'.$post->slug)); ?>"> <?php echo e(url('blog/'.$post->slug)); ?> </a> </dd>
			</dl>

			<dl class="dl-horizontal">
				<dt> Category: </dt>
				<dd> <?php echo e($post->category->name); ?> </dd>
			</dl>

			<dl class="dl-horizontal">
				<dt> Created At: </dt>
				<dd> <?php echo e(date ('j.M.Y , H:i', strtotime ($post->created_at))); ?> </dd>
			</dl>

			<dl class="dl-horizontal">
				<dt>  Last Updated At:  </dt>
				<dd> <?php echo e(date ('j.M.Y , H:i', strtotime ($post->updated_at))); ?> </dd>
			</dl>
			<dl class="dl-horizontal">
			<?php echo Html::linkRoute ('posts.index', '< Show All', array(), array('class' => 'btn btn-default btn-block')); ?>

			</dl>


			<hr>

			<div class="row">
				<div class="col-sm-6">
					<?php echo Html::linkRoute ('posts.edit', 'Edit', array($post->id), array('class' => 'btn btn-info btn-block')); ?>

					
				</div>
				<div class="col-sm-6">
					<?php echo Form::open (['route' => ['posts.destroy', $post->id], 'method' => 'DELETE']); ?>

					<?php echo e(Form::submit('Destroy', ['class' => 'btn btn-danger btn-block'])); ?>

					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>
				
					
				
	<?php else: ?>
	<div class="col-md-12">
		<h1> This is not your post! </h1>
	</div>
	<?php endif; ?>
</div>

	<?php if($globalbr > 4): ?>
	<p class="pNoComment"> You can upload just 5 images! </p>
	<?php else: ?>
	<h3> Add Images: </h3>
	<form name="file" action="/posts/image-upload/<?php echo e($post->id); ?>"
      class="dropzone"
      id="my-dropzone" method="POST">
      	<?php echo e(csrf_field()); ?>

      </form>
     <?php endif; ?>

<script type="text/javascript">
		$(document).ready(function(){
			$('.lightbox').fancybox();
		});

</script>
<script>

	Dropzone.options.myDropzone = {

       
		<?php $maxfiles = 5; ?>
		maxFiles: <?php echo e($maxfiles - $globalbr); ?>,
		maxFilesize: 10,
		acceptedFiles: "image/*",
		

		init: function() {
          console.log('init');
          this.on("maxfilesexceeded", function(file){
                alert("No more files please!");
                this.removeFile(file);
          });
		},

		success: function (file, response){
			if (file.status == 'success'){
				handleDropzoneFileUpload.handleSuccess(response);
			}
			else{
				handleDropzoneFileUpload.handleError(response);
			}
		}
	};
		var handleDropzoneFileUpload = {
		handleError: function(response){
			console.log(response);
		},
		handleSuccess: function(response){
			var baseUrl = "<?php echo e(asset('/')); ?>";
			var imageSrc =  baseUrl + 'images/' + response.name; 
			//var selector = document.getElementById('fuckimgs');
			//selector.innerHTML = '<h1>string of html content</h1>';
			$('#fuckimgs').append('<a data-fancybox="group" class="lightbox" href="'+ imageSrc +'"><img vspace="20" src="'+ imageSrc +'" width="300"></a> ');
			var deleteSrc = baseUrl + 'posts/' + response.post_id + '/delete-image/' + response.id;
			$('#fuckimgs').append('<form name="delete-image" action="'+ deleteSrc +'" method="DELETE">  <input type="submit" value="Delete" class="btn btn-danger btn-sm"> </form> ');
		}
	};
	</script>

	


	

	



<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>