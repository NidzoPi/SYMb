<?php $__env->startSection('title', "| $post->title"); ?>

<?php $__env->startSection('scriptsandlinks'); ?>
<meta property="og:image" content="<?php echo e($post->images); ?>" />
<meta property="og:title" content="<?php echo e($post->title); ?>" />
<meta property="og:description" content="<?php echo e($post->body); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-8 col-md-offset-2">
		<h2 class="BlogTitle"> <?php echo e($post->title); ?> </h2>
		<?php $br = 0; ?>
		<?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($br < 1): ?>
			<a data-fancybox="group" class="lightbox" href="<?php echo e(asset('images/'. $image->name)); ?>">
			<img id="trebapaddinga" src="<?php echo e(asset('images/'. $image->name)); ?>" width="400" height="auto" />
			</a>
			<?php else: ?>
			<a data-fancybox="group" class="lightbox" href="<?php echo e(asset('images/'. $image->name)); ?>">
			<img style="display: none;" src="<?php echo e(asset('images/'. $image->name)); ?>" width="500" />
			</a>
			<?php endif; ?>
		<?php $br = $br + 1; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<div class="zakubike"> <?php echo e($post->ccm); ?> ccm </div>
		<div class="zakonje"> <?php echo e($post->hp); ?> HP </div>
		<div class="zagodine"> <?php echo e($post->year); ?> year </div>
		<p id="trebapaddinga" class="dont-break-out"> <?php echo e($post->body); ?>  </p>
		<hr>
		<div class="tags">
			<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<button type="button" class="btn btn-info btn-sm">
				<?php echo e($tag->name); ?>

			</button>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<br>
		<strong> <p> Posted In: <?php echo e($post->category->name); ?> </p> </strong>
		<strong> <p> Owner: <?php echo e($user->name); ?> </p> </strong>

		<?php if($post->sale == 0): ?>
			<h4 id="notforsale"> Not For Sale </h4>
		<?php elseif($post->sale == 1): ?>
			<div id = "forsale">
			<h4> For Sale </h4>
			<p> <?php echo e($post->phone_number); ?> </p>
		</div>
		<?php else: ?>
			<h4> Hahah </h4>
		<?php endif; ?>

	</div>

	<div class="col-md-2">
		<?php if(Auth::check()): ?>
		<?php $help = 0; ?>
		<?php $__currentLoopData = $post->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(Auth::user()->id == $review->user_id): ?>
			<?php $help = $help + 1; ?>
			<?php else: ?>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php if($help < 1): ?>
			<div class="well">
				<?php echo Form::open(['route' => 'review.store', 'method' => 'POST']); ?>

				<?php echo e(Form::label ('rating', 'Rate:')); ?>

				<?php echo e(Form::select('rating', [
				   '1' => '1',
				   '2' => '2',
				   '3' => '3',
				   '4' => '4',
				   '5' => '5',
				   '6' => '6',
				   '7' => '7',
				   '8' => '8',
				   '9' => '9',
				   '10' => '10',
					 '11' => '11',
					 '12' => '12'
				], null, ['class' => 'form-control']
				)); ?>

				<?php echo e(Form::label ('headline', 'Why?')); ?>

				<?php echo e(Form::text('headline', null, ['class' => 'form-control'])); ?>

				<br>
				<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>"/>
				<?php echo e(Form::submit('Vote', ['class' => 'btn btn-danger btn-block'])); ?>

				<?php echo Form::close(); ?>

			</div>
			<?php else: ?>
			<p class="pNoComment"> You have already voted for this bike! </p>
			<?php endif; ?>
			<?php else: ?>
			<?php endif; ?>
			<div class="well">

				<?php $varreviewcount =  $post->reviews()->count(); $br = 0; ?>
				<p class="pageViewsandVotes pNoComment"> Votes: <?php echo e($varreviewcount); ?> </p>
				<?php $__currentLoopData = $post->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				 	<?php if($post->id == $review->post_id): ?>
				 	<?php $br = $br + $review->rating; ?>

				 	<?php else: ?>
				 	<? $br = 0; $varreviewcount = 0; ?>
				 	<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php if ($varreviewcount > 0) {$arsredina = $br / $varreviewcount;} else {$arsredina = 0;} ?>
				<?php for ($i = 0; $i < $arsredina; $i++) { ?>
					<img width="20px" height="20px" src="/images/dodaci/star.png"/>
				<?php } ?>
				<p class="pageViewsandVotes pNoComment"> Views: 	<?php echo e($post->getPageViews()); ?> </p>

			</div>
	</div>
</div>
<div class="row">
	<div class="col-md-6">
<?php if(auth()->guard()->guest()): ?>
<p class="pNoComment"> You aren't allowed to comment, because you aren't logged in! </p>
<?php else: ?>
 <?php echo e(Form::open (['route' => ['comments.store', $post->id], 'method' => 'POST'])); ?>

 	<div class="row">
 		<div class="col-md-2">
 			<a href="#">
            <?php echo e(Auth::user()->name); ?>

        	</a>
 		</div>
 		<div class="col-md-10">
 			<strong> <?php echo e(Form::label ('comment', 'Leave a comment:')); ?> </strong>
 			<?php echo e(Form::textarea('comment', null, ['class' => 'form-control', 'rows' => '5', 'minlength' => '5', 'maxlength' => '255'])); ?>

 			<?php echo e(Form::submit('Add Comment', ['class' => 'btn btn-success btn-block', 'style' => 'margin-top: 10px;'])); ?>

 		</div>
 	</div>
 <?php echo e(Form::close()); ?>

<?php endif; ?>
	</div>
</div>


<div class="row udalji">
	<div class="col-md-8 md-offset-2">
		<h3 class="comments-title"> <img src="/images/dodaci/comment.png" class="img-comment"/> </span><?php echo e($post->comments()->count()); ?> Comments: </h3>
	<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="comment">

			<div class="author-info">
				<img src="<?php echo e("https://www.gravatar.com/avatar/" . md5(strtolower(trim($comment->user->email))) . "?d=mm"); ?>" class="author-image">
				<div class="author-name">
				<h4>	<?php echo e($comment->user->name); ?> </h4>
				<p class="author-time"><?php echo e(date('j.M.Y',strtotime($comment->created_at))); ?></p>
				</div>
			</div>

			<div class="comment-content">
				<?php echo e($comment->comment); ?>


					<div class="deletebutton">
						<?php if(auth()->guard()->guest()): ?>
		   	 				<p>  </p>
		   	 			<?php else: ?>
		   	 			<?php if(Auth::user()->id == $comment->user->id): ?>
		   	 				<?php echo Form::open (['route' => ['comments.destroy', $comment->id], 'method' => 'DELETE']); ?>


							<?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger btn-block btn-sm'])); ?>


							<?php echo Form::close(); ?>

		   	 			<?php else: ?>
		   	 				<p> </p>
		   	 			<?php endif; ?>
		   	 			<?php endif; ?>
		   			</div>
		   </div>

		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<script type="text/javascript">

		$(document).ready(function(){

			$('.lightbox').fancybox();


		});



</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>