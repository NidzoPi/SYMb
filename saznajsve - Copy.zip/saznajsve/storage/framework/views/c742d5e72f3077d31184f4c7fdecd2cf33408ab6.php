<?php $__env->startSection('title', '| Welcome'); ?>
<?php $__env->startSection('scriptsandlinks'); ?>
	<meta property="og:image" content="http://www.pngall.com/wp-content/uploads/2016/05/Motorcycle-Helmet-High-Quality-PNG.png" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
</div>

<div class="container-full">
	 <div class="row">
		<div class="col-md-12">
			<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner" role="listbox">
    <div class="carousel-item active">
      <img class="d-block img-fluid" src="/images/pic/moto1.jpg" alt="First slide" width="100%">
			<div class="carousel-caption">
					<p>Emo Philips</p>
		 </div>
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="/images/pic/moto2.jpg" alt="Second slide" width="100%">
			<div class="carousel-caption">
					<p>Anonymous</p>
		 </div>
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="/images/pic/moto3.jpg" alt="Third slide" width="100%">
			<div class="carousel-caption">
					<p>Anonymous</p>
		 </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
		</div>
	</div>
</div>
<div class="container welcomedrugi">
	<h3 class="BlogTitle"> New Bikes Posted: </h3>
	<br>
	<div class="row">
		<div class="card-deck">
			<?php $bla = 0; ?>
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $bla = $bla + 1; ?>
				<?php $br = 0; ?>
		<?php if($post->images->count() != 0): ?>
				<?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($br < 1): ?>
					<div class="card" style="width: 18rem;">
						<a href="<?php echo e(route('blog.single', $post->slug)); ?>">
						<img class="card-img-top" src="<?php echo e(asset('images/'. $image->name)); ?>" height="300" />
						</a>
						<div class="card-body">
							 <h5 class="card-title"><?php echo e($post->title); ?></h5>
							 <p class="card-text"><?php echo e(substr($post->body, 0, 100)); ?> <?php echo e(strlen($post->body) > 100 ? "..." : ""); ?></p>
							 <a href="<?php echo e(url('blog/'. $post->slug)); ?>" class="btn btn-primary"> Read More </a> <p id="views"> Views: <?php echo e($post->getPageViews()); ?> </p>
						</div>
					</div>
						<?php else: ?>
						<?php endif; ?>
					<?php $br = $br + 1; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<?php if($br < 1): ?>
			<div class="card" style="width: 18rem;">
				<a href="<?php echo e(route('blog.single', $post->slug)); ?>">
				<img class="card-img-top" src="<?php echo e(url ('images/dodaci/noimage.gif')); ?>" height="300" />
				</a>
				<div class="card-body">
					 <h5 class="card-title"><?php echo e($post->title); ?></h5>
					 <p class="card-text"><?php echo e(substr($post->body, 0, 100)); ?> <?php echo e(strlen($post->body) > 100 ? "..." : ""); ?></p>
					 <a href="<?php echo e(url('blog/'. $post->slug)); ?>" class="btn btn-primary"> Read More </a> <p id="views"> Views: <?php echo e($post->getPageViews()); ?> </p>
				</div>
			</div>
				<?php else: ?>
				<?php endif; ?>
			<?php $br = $br + 1; ?>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 		</div>
	</div>
</div>

<div class="container welcomedrugi">
	<h3 class="BlogTitle">Most viewed Bikes: </h3>
	<br>
<div class="row">
	<div class="card-deck">
		<?php $__currentLoopData = $vposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $br = 0; $brr = 0; ?>
				<?php if($vpost->images->count() != 0): ?>
				<?php $__currentLoopData = $vpost->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($br < 1): ?>
				<div class="card" style="width: 18rem;">
						<a href="<?php echo e(route('blog.single', $vpost->slug)); ?>">
						<img class="card-img-top" src="<?php echo e(asset('images/'. $image->name)); ?>" height="300" />
						</a>
						<div class="card-body">
							 <h5 class="card-title"><?php echo e($vpost->title); ?></h5>
							 <p class="card-text"><?php echo e(substr($vpost->body, 0, 100)); ?> <?php echo e(strlen($vpost->body) > 100 ? "..." : ""); ?></p>
							 <a href="<?php echo e(url('blog/'. $vpost->slug)); ?>" class="btn btn-primary"> Read More </a> <p id="views"> Views: <?php echo e($vpost->getPageViews()); ?> </p>
					 </div>
				</div>
				<?php else: ?>
				<?php endif; ?>
					<?php $br = $br + 1; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
				<?php if($br < 1): ?>
			<div class="card" style="width: 18rem;">
					<a href="<?php echo e(route('blog.single', $vpost->slug)); ?>">
					<img class="card-img-top" src="<?php echo e(url('images/dodaci/noimage.gif')); ?>" height="300" />
					</a>
					<div class="card-body">
						 <h5 class="card-title"><?php echo e($vpost->title); ?></h5>
						 <p class="card-text"><?php echo e(substr($vpost->body, 0, 100)); ?> <?php echo e(strlen($vpost->body) > 100 ? "..." : ""); ?></p>
						 <a href="<?php echo e(url('blog/'. $vpost->slug)); ?>" class="btn btn-primary"> Read More </a> <p id="views"> Views: <?php echo e($vpost->getPageViews()); ?> </p>
					</div>
				</div>
				<?php else: ?>
				<?php endif; ?>
				<?php $br = $br + 1; ?>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 		</div>
	</div>
</div>

<div class="container welcomedrugi">
	<h3 class="BlogTitle">Most popular Bikes: </h3>
	<br>
	<div class="row">
			<div class="card-deck">
				<?php $aha = 0; ?>
		<?php $__currentLoopData = $rposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $aha = $aha + 1; ?>
			<?php $__currentLoopData = $pomocposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pomocpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $br = 0; $brr = 0; ?>
				<?php if($rpost->id == $pomocpost->id): ?>
					<?php if($pomocpost->images->count() != 0 ): ?>
					<?php $__currentLoopData = $pomocpost->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($br < 1): ?>

						<div class="card" style="width: 18rem;">
							<a href="<?php echo e(route('blog.single', $pomocpost->slug)); ?>">
							<img class="card-img-top" src="<?php echo e(asset('images/'. $image->name)); ?>" height="300" />
							</a>
							<div class="card-body">
								 <h5 class="card-title"><?php echo e($pomocpost->title); ?></h5>
								 <p class="card-text"><?php echo e(substr($pomocpost->body, 0, 100)); ?> <?php echo e(strlen($pomocpost->body) > 100 ? "..." : ""); ?></p>
								 <a href="<?php echo e(url('blog/'. $pomocpost->slug)); ?>" class="btn btn-primary"> Read More </a> <p id="views"> Views: <?php echo e($pomocpost->getPageViews()); ?> </p>
							</div>
						</div>
						<?php else: ?>
						<?php endif; ?>
						<?php $br = $br + 1; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<?php if($br < 1): ?>

					<div class="card" style="width: 18rem;">
						<a href="<?php echo e(route('blog.single', $pomocpost->slug)); ?>">
						<img class="card-img-top" src="<?php echo e(url('images/dodaci/noimage.gif')); ?>" height="300" />
						</a>
						<div class="card-body">
							 <h5 class="card-title"><?php echo e($pomocpost->title); ?></h5>
							 <p class="card-text"><?php echo e(substr($pomocpost->body, 0, 100)); ?> <?php echo e(strlen($pomocpost->body) > 100 ? "..." : ""); ?></p>
							 <a href="<?php echo e(url('blog/'. $pomocpost->slug)); ?>" class="btn btn-primary"> Read More </a> <p id="views"> Views: <?php echo e($pomocpost->getPageViews()); ?> </p>
						</div>
					</div>
					<?php else: ?>
					<?php endif; ?>
					<?php $br = $br + 1; ?>
				<?php endif; ?>
				<?php else: ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php if($aha == 4): ?>
				<?php break; ?>
			<?php else: ?>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>