<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php echo Html::style('css/styles.css'); ?>

    <?php echo Html::style('css/fornavstyles.css'); ?>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'SYMb')); ?></title>

    <!-- Styles -->

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">SYMb</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse divina" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item  <?php echo e(Request::is('/') ? "active" : ""); ?>">
        <a class="nav-link" href="/" >Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item <?php echo e(Request::is('blog') ? "active" : ""); ?>">
        <a class="nav-link" href="/bikes">Bikes</a>
      </li>
     <li class="nav-item <?php echo e(Request::is('contact') ? "active" : ""); ?>">
        <a class="nav-link" href="/contact">Contact Us</a>
      </li>
    </ul>


    <ul class="navbar-nav ml-auto menug">
      <form method="GET" action="<?php echo e(route('search')); ?>">
        <input autocomplete="off" minlength="3" maxlength="29" type="text" name="search" value="<?php echo e(request()->input('search')); ?>" placeholder="Search..">
      </form>

                        <?php if(auth()->guard()->guest()): ?>
                            <li class="linav"><a id="anav" href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li class="linav"><a id="anav" href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="dropdown show userludi dropdownn">
                                <a id="anav" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>


                                <ul class="dropdown-menu dropdown-menu-right menud  bg-dark">

                                     <li id="menu" class="dropdown-item">
                                       <a id="sve" href="/posts"> <div id="stopo"> Posts </div> </a>
                                    </li>
                                    <?php if(Auth::user()->admin != 0): ?>
                                     <li id="menu" class="dropdown-item">
                                       <a href="<?php echo e(route('categories.index')); ?>"> Categories </a>
                                    </li>
                                      <li class="dropdown-item">
                                       <a href="<?php echo e(route('tags.index')); ?>"> Tags </a>
                                    </li>
                                  <?php else: ?>
                                  <?php endif; ?>
                                    <div class="dropdown-divider"></div>
                                    <li  class="dropdown-item">
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>

                                </ul>
                            </li>
                        <?php endif; ?>
    </ul>
  </div>
</nav>
</body>
</html>
