<?php $__env->startSection('title', "| $tag->name Tag"); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-8">
		<h2> <?php echo e($tag->name); ?> Tag <small> <?php echo e($tag->posts()->count()); ?> Posts </small></h2> 
	</div>
	<div class="col-md-2">
		<a href="<?php echo e(route('tags.edit', $tag->id)); ?>" class="btn btn-primary btn-lg"> Edit </a>
	</div>
	<div class="col-md-2">
		<?php echo e(Form::open(['route' => ['tags.destroy', $tag->id], 'method' => 'DELETE'])); ?>

			<?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger btn-lg'])); ?>


		<?php echo e(Form::close()); ?>

	</div>
</div>
<br>
<div class="row" style="margin-top: 50px;">
	<div class="col-md-12">
		<table class="table">
			<thead>
				<tr>
					<th> ID </th>
					<th> Post </th>
					<th> Tags </th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $tag->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<th> <?php echo e($post->id); ?> </th>
					<td> <?php echo e($post->title); ?> </td>
					<td>
					<?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <button class="btn btn-default btn-sm"> <?php echo e($tag->name); ?></button> 
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</td>
					<td> <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-default btn-sm"> View </a> </td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>		
		</table>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>