From: <?php echo e($email); ?> <br><br><br>
 <b> Message: </b> <p style="font-size: 20px;"> <?php echo e($bodyMessage); ?> </p>
