<?php $__env->startSection('title', "| DELETE COMMENT"); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-8">
		<h1> DELETE THIS COMMENT? </h1>
		<p>
			<strong> Comment: </strong> <?php echo e($comment->comment); ?>

		</p>
		<?php echo e(Form::open(['route' => ['comments.destroy', $comment->id ], 'method' => 'POST'])); ?>


		<?php echo e(Form::submit ('Yes Delete This Comment', ['class' => 'btn btn-danger btn-lg btn-block'])); ?>


		<?php echo e(Form::close()); ?>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>