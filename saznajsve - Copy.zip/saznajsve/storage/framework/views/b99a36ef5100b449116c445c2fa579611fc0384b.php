<?php $__env->startSection('title', '| Bikes'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12 offset-md-2">

	</div>
</div><br>
<hr>
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
	<div class="col-md-8 offset-md-2">
		<h2> <?php echo e($post->title); ?> </h2>
		<p> Published: <?php echo e(date('j.M.Y', strtotime ($post->created_at))); ?> </p>
			<?php $br = 0 ?>
		<?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($br < 1): ?>
			<a href="<?php echo e(route('blog.single', $post->slug)); ?>">
			<img src="<?php echo e(asset('images/'. $image->name)); ?>" width="400" height="auto" />
			<?php else: ?>
			<?php endif; ?>
			<?php $br = $br + 1; ?>
			</a>


		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<p id="trebapaddinga" class="dont-break-out"> <?php echo e(substr($post->body, 0, 250)); ?> <?php echo e(strlen($post->body) > 250 ? '...' : ''); ?> </p>

		<a href="<?php echo e(route('blog.single', $post->slug)); ?>"> Read More </a>
		<hr>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="row">
	<div class="col-md-12">
		<div class="text-center">
			<?php echo $posts->links(); ?>

		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>