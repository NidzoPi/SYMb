<?php $__env->startSection('title', '| Dobrodosli'); ?>


<?php $__env->startSection('content'); ?><br>


	 <div class="row">
		<div class="col-md-12">
			<div class="jumbotron">
			<h1 align="center"> SAZNAJ SVE </h1>
			<p class="lead" align="center"> Budi bolji od svih prati Saznaj Sve! </p>
			</div>
		</div>
	</div>
	<h3 class="BlogTitle"> New Cars Posted: </h3>
	<br>
	<div class="row"> 
		<div class="card-deck"> 
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
				<?php $br = 0 ?>
		
				<?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<?php if($br < 1): ?>
					<div class="card" style="width: 18rem;">
						<a href="<?php echo e(route('blog.single', $post->slug)); ?>">
						<img class="card-img-top" src="<?php echo e(asset('images/'. $image->name)); ?>" height="300" />
						</a>
						<div class="card-body">
							 <h5 class="card-title"><?php echo e($post->title); ?></h5>
							 <p class="card-text"><?php echo e(substr($post->body, 0, 100)); ?> <?php echo e(strlen($post->body) > 100 ? "..." : ""); ?></p>
							 <a href="<?php echo e(url('blog/'. $post->slug)); ?>" class="btn btn-primary"> Read More </a>
						</div>
					</div>
					<?php else: ?>
					<?php endif; ?>

					<?php $br = $br + 1; ?>
			
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
 		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>