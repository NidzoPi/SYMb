<?php $__env->startSection('title', '| Create Post'); ?>

<?php $__env->startSection('scriptsandlinks'); ?>
<?php echo Html::style('css/parsley.css'); ?>

<?php echo Html::script('js/parsley.min.js'); ?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

<script type="text/javascript">
	$(document).ready(function() {
    $('.js-example-basic-multiple').select2();
	});
</script>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	
	<div class="col-md-12 col-md-offset-4">
		<h1> Create Post </h1>
		<hr>

		<?php echo Form::open(['route' => 'posts.store', 'data-parsly-validate' => '', 'files' => true, 'id' => 'form1']); ?>


		<?php echo e(Form::label ('title', 'Title:')); ?>

		<?php echo e(Form::text ('title', null, array('class' => 'form-control', 'required' => '', 'maxlength' => '255'))); ?>


		

		<?php echo e(Form::label('category_id', 'Category: ')); ?>

		<select class="form-control" name="category_id">
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?> </option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>

		<?php echo e(Form::label('tags', 'Tags: ')); ?>

		<select class="form-control js-example-basic-multiple" name="tags[]" multiple="multiple">
			<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($tag->id); ?>"> <?php echo e($tag->name); ?> </option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>

   		<?php echo e(Form::label ('body', 'Body:')); ?>

   		<?php echo e(Form::textarea('body', null, array ('class' => 'form-control', 'required' => '', 'maxlength' => '500'))); ?>

   		<br>
   		<?php echo e(Form::submit('Create Post', ['class' => 'btn btn-success btn-block button1'])); ?>


		<?php echo Form::close(); ?>


	

	</div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>