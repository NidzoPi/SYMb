<?php $__env->startSection('title', '| Create Post'); ?>

<?php $__env->startSection('scriptsandlinks'); ?>
<?php echo Html::style('css/parsley.css'); ?>

<?php echo Html::script('js/parsley.min.js'); ?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>



<script type="text/javascript">
	$(document).ready(function() {
    $('.js-example-basic-multiple').select2();
	});
</script>
<script>
$(function(){
	$('#form1').submit(function(event){
		var verified = grecaptcha.getResponse();
		if (verified.length === 0){
			document.getElementById('redara').innerHTML = 'Are you really a robot?';
			event.preventDefault();
		}
	});
});
</script>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">

	<div class="col-md-10 col-md-offset-2">
		<h1> Create Post </h1>
		<hr>

		<?php echo Form::open(['route' => 'posts.store', 'data-parsly-validate' => '', 'files' => true, 'id' => 'form1']); ?>


		<?php echo e(Form::label ('title', 'Model:')); ?>

		<?php echo e(Form::text ('title', null, array('class' => 'form-control', 'required' => '', 'maxlength' => '255'))); ?>


		<?php echo e(Form::label('sale', 'For sale:')); ?>

		<select class="form-control" name="sale" onchange="showDiv(this)">
			<option value="0"> NO </option>
			<option value="1"> YES </option>
		</select>
		<div id="phone_number" style="display: none;"> Phone number : <input name="phone_number" type = "textarea">
		 </div>
		<script>
		function showDiv(elem){
   			if(elem.value == 1){
      	document.getElementById('phone_number').style.display = "block";
				}
				else{
					document.getElementById('phone_number').style.display = "none";
				}
		}
		</script>
		<?php echo e(Form::label('category_id', 'Category: ')); ?>

		<select class="form-control" name="category_id">
			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?> </option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>

		<?php echo e(Form::label('tags', 'Tags: ')); ?>

		<select class="form-control js-example-basic-multiple" name="tags[]" multiple="multiple">
			<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($tag->id); ?>"> <?php echo e($tag->name); ?> </option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>


	<div class="col-md-2">
		<?php echo e(Form::label('ccm', 'ccm:')); ?>

		<input type="number" name="ccm" min="49" max="1500" class="form-control" placeholder="49-1500">
	</div>
	<div class="col-md-2">
		<?php echo e(Form::label('hp', 'Horse Power: ')); ?>

		<input type="number" name="hp" min="1" max="1000"  class="form-control" placeholder="1-1000" step=".01">
	</div>
	<div class="col-md-2">
		<?php echo e(Form::label('year', 'Year: ')); ?>

		<input type="year" name="year" min="1910" max="<?php echo date("Y"); ?>"  class="form-control" placeholder="1910-<?php echo date("Y"); ?>" step=".01">
	</div>


   		<?php echo e(Form::label ('body', 'About you and your motorcycle:')); ?>

   		<?php echo e(Form::textarea('body', null, array ('class' => 'form-control', 'id' =>'editor', 'required' => '','minlength' => '100', 'maxlength' => '1000'))); ?>

   		<br>
			<div style="padding-bottom: 20px;" class="g-recaptcha" data-sitekey="6Ld961kUAAAAAIGxahqCq0fT5uBMm65uzeFh6xCe"></div>
			<p id="redara"></p>
   		<?php echo e(Form::submit('Create Post', ['class' => 'btn btn-success btn-block button1'])); ?>


		<?php echo Form::close(); ?>




	</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>