<!DOCTYPE html>
<html>
<head>
<?php echo $__env->make('partials._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>

<?php echo $__env->make('partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--  -->
<div class="container">
		<?php echo $__env->make('partials._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldContent('content'); ?>

</div>
<hr>
<div class="footer">
	<?php if(Auth::check()): ?>
	<div class="footer1">
		<img class = "kaciga" src = "/images/dodaci/kaciga.png"/>
	</div>
	<div class="footer2">
		<p id="usersinfooter2"> = 	<?php echo e(Auth::user()->count()); ?> 	 </p>
	</div>
	<?php else: ?>
	<?php endif; ?>

		<a id="nikola" href = "https://www.facebook.com/nikola.plilipovic" target="_blank">
			<p id="nidzo" class="text-center"> © NPilipovic </p>
		</a>
		<p class="version-center"> Version 1.0 </p>
</div>
</body>
</html>
