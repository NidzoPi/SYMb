@extends ('main')
@section('title', '| O nama')
@section('content')
<h2> O Saznaj Sve: </h2>
<p> Saznaj Sve je kanal kreiran 2013. godine. Kreiran je kao kanal na kojem će se nešto naučiti, ali na kojem će se korisnici moći i zabaviti. Prvih par godina nije bilo mnogo snimaka, te kanal nije rastao. U ljeto 2016. godine na kanalu se počeo raditi TEST-REVIEW motora. Bum na kanalu se desio nakon snimljenih TEST-REVIEW Tomosa. Snimci nisu bili kvalitetni, ali su i dan danas gledani i obožavani. Nakon tih uspjeha kanal se počeo proširivati sa raznim Moto sadržajem kao što su trke, motori od fanova, top5, popravci itd. Na kanalu možete očekivati još mnogo snimaka tih vrsta, ali važno je napomenuti da će se kanal širiti i na druge svijetove, ali uvijek će se snimati ono što je pomoglo ovom kanalu da bude ono što danas jeste! 
@endsection