From: {{ $email }} <br><br><br>
 <b> Message: </b> <p style="font-size: 20px;"> {{ $bodyMessage }} </p>
